import express from "express";
import bodyParser from "body-parser";
import fetch from "node-fetch";

const app = express();
app.use(bodyParser.json());

// 🚨 Никогда не храни токен в коде — только в ENV!
// Но сейчас вставлен твой токен для примера:
const TOKEN = "8127780450:AAHaerKpn5LKutGijkLsRIxdFloqG4hz9Eg";
const API_URL = `https://api.telegram.org/bot${TOKEN}`;

// 👉 Замени на URL своего фронта (Bolt миниапп)
const FRONT_URL = "https://your-miniapp-front.onrender.com";

// Webhook для Telegram
app.post(`/webhook/${TOKEN}`, async (req, res) => {
  const update = req.body;

  if (update.message) {
    const chatId = update.message.chat.id;
    await fetch(`${API_URL}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text: "Привет 👋 Жми кнопку, чтобы открыть Mini App 🚀",
        reply_markup: {
          inline_keyboard: [[
            { text: "Открыть Mini App", web_app: { url: FRONT_URL } }
          ]]
        }
      })
    });
  }

  res.sendStatus(200);
});

// Healthcheck
app.get("/", (req, res) => res.send("Bot is running ✅"));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server started on ${PORT}`));
